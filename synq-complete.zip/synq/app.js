/**
 * SYNQ - Social Media Platform
 * Main Application JavaScript
 */

// ============================================
// CONFIGURATION
// ============================================

const API_URL = '/api';
let currentUser = null;
let authToken = null;

// ============================================
// INITIALIZATION
// ============================================

document.addEventListener('DOMContentLoaded', () => {
  // Check if user is logged in
  const token = localStorage.getItem('authToken');
  if (token) {
    authToken = token;
    loadUserProfile();
    showMainApp();
  } else {
    showAuthPage();
  }

  // Event listeners
  document.getElementById('postImage').addEventListener('change', handleImagePreview);
  document.getElementById('searchInput').addEventListener('input', handleSearch);
});

// ============================================
// AUTH FUNCTIONS
// ============================================

function toggleAuthForm() {
  const loginForm = document.getElementById('loginForm');
  const signupForm = document.getElementById('signupForm');
  
  loginForm.classList.toggle('active');
  signupForm.classList.toggle('active');
}

async function handleLogin() {
  const email = document.getElementById('loginEmail').value;
  const password = document.getElementById('loginPassword').value;

  if (!email || !password) {
    showError('Please fill in all fields');
    return;
  }

  try {
    const response = await fetch(`${API_URL}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password })
    });

    const data = await response.json();

    if (!response.ok) {
      showError(data.error || 'Login failed');
      return;
    }

    authToken = data.data.token;
    localStorage.setItem('authToken', authToken);
    
    await loadUserProfile();
    showMainApp();
    showToast('Welcome back!', 'success');
  } catch (error) {
    showError('Login failed: ' + error.message);
  }
}

async function handleSignup() {
  const name = document.getElementById('signupName').value;
  const email = document.getElementById('signupEmail').value;
  const username = document.getElementById('signupUsername').value;
  const password = document.getElementById('signupPassword').value;

  if (!name || !email || !username || !password) {
    showError('Please fill in all fields');
    return;
  }

  try {
    const response = await fetch(`${API_URL}/auth/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ full_name: name, email, username, password })
    });

    const data = await response.json();

    if (!response.ok) {
      showError(data.error || 'Signup failed');
      return;
    }

    authToken = data.data.token;
    localStorage.setItem('authToken', authToken);
    
    await loadUserProfile();
    showMainApp();
    showToast('Account created successfully!', 'success');
  } catch (error) {
    showError('Signup failed: ' + error.message);
  }
}

function handleLogout() {
  localStorage.removeItem('authToken');
  authToken = null;
  currentUser = null;
  showAuthPage();
  showToast('Logged out successfully', 'success');
}

// ============================================
// USER FUNCTIONS
// ============================================

async function loadUserProfile() {
  try {
    const response = await fetch(`${API_URL}/users/profile`, {
      headers: { 'Authorization': `Bearer ${authToken}` }
    });

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.error);
    }

    currentUser = data.data;
    updateUserUI();
    await loadFeed();
    await loadTrending();
    await loadSuggestedUsers();
  } catch (error) {
    console.error('Failed to load profile:', error);
  }
}

function updateUserUI() {
  const initials = (currentUser.full_name || 'U').substring(0, 1).toUpperCase();
  
  document.getElementById('userAvatar').textContent = initials;
  document.getElementById('createAvatar').textContent = initials;
  document.getElementById('userName').textContent = currentUser.full_name || 'User';
  document.getElementById('userUsername').textContent = '@' + (currentUser.username || 'user');
  document.getElementById('postsCount').textContent = currentUser.posts_count || 0;
  document.getElementById('followersCount').textContent = currentUser.followers_count || 0;
  document.getElementById('followingCount').textContent = currentUser.following_count || 0;
}

// ============================================
// POST FUNCTIONS
// ============================================

async function loadFeed() {
  try {
    const response = await fetch(`${API_URL}/feed`, {
      headers: { 'Authorization': `Bearer ${authToken}` }
    });

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.error);
    }

    renderFeed(data.data || []);
  } catch (error) {
    console.error('Failed to load feed:', error);
  }
}

function renderFeed(posts) {
  const container = document.getElementById('feedContainer');

  if (posts.length === 0) {
    container.innerHTML = '<div class="empty-state"><p>📝 No posts yet. Start following people!</p></div>';
    return;
  }

  container.innerHTML = posts.map(post => `
    <div class="post" data-post-id="${post.id}">
      <div class="post-header">
        <div class="post-user-info">
          <div class="post-avatar">${post.full_name.substring(0, 1).toUpperCase()}</div>
          <div class="post-info">
            <h4>${post.full_name}</h4>
            <p class="post-time">${formatDate(post.created_at)}</p>
          </div>
        </div>
        <button class="nav-btn">⋯</button>
      </div>
      ${post.image_url ? `<img src="${post.image_url}" class="post-image" alt="Post">` : ''}
      ${post.caption ? `<div class="post-content">${post.caption}</div>` : ''}
      <div class="post-stats">
        <span>${post.likes_count || 0} likes</span>
        <span>${post.comments_count || 0} comments</span>
      </div>
      <div class="post-actions">
        <button class="post-btn" onclick="likePost(${post.id})">❤️ Like</button>
        <button class="post-btn" onclick="toggleComments(${post.id})">💬 Comment</button>
        <button class="post-btn">↗️ Share</button>
      </div>
      <div class="comments-section" id="comments-${post.id}">
        <div id="comments-list-${post.id}"></div>
        <div class="comment-input-container">
          <input type="text" class="comment-input" placeholder="Add a comment..." id="comment-input-${post.id}">
          <button class="btn-send" onclick="addComment(${post.id})">➤</button>
        </div>
      </div>
    </div>
  `).join('');
}

async function likePost(postId) {
  try {
    const response = await fetch(`${API_URL}/posts/${postId}/like`, {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${authToken}` }
    });

    const data = await response.json();

    if (!response.ok) {
      showError(data.error);
      return;
    }

    await loadFeed();
    showToast('Post liked!', 'success');
  } catch (error) {
    showError('Failed to like post');
  }
}

async function toggleComments(postId) {
  const section = document.getElementById(`comments-${postId}`);
  section.classList.toggle('active');

  if (section.classList.contains('active')) {
    await loadComments(postId);
  }
}

async function loadComments(postId) {
  try {
    const response = await fetch(`${API_URL}/posts/${postId}/comments`, {
      headers: { 'Authorization': `Bearer ${authToken}` }
    });

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.error);
    }

    renderComments(postId, data.data || []);
  } catch (error) {
    console.error('Failed to load comments:', error);
  }
}

function renderComments(postId, comments) {
  const container = document.getElementById(`comments-list-${postId}`);

  if (comments.length === 0) {
    container.innerHTML = '<p style="text-align: center; color: var(--text-tertiary); font-size: 12px;">No comments yet</p>';
    return;
  }

  container.innerHTML = comments.map(comment => `
    <div class="comment">
      <div class="comment-avatar">${comment.full_name.substring(0, 1).toUpperCase()}</div>
      <div class="comment-body">
        <div class="comment-bubble">
          <div class="comment-username">${comment.full_name}</div>
          <div class="comment-text">${comment.text}</div>
        </div>
      </div>
    </div>
  `).join('');
}

async function addComment(postId) {
  const input = document.getElementById(`comment-input-${postId}`);
  const text = input.value.trim();

  if (!text) {
    showError('Comment cannot be empty');
    return;
  }

  try {
    const response = await fetch(`${API_URL}/posts/${postId}/comments`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${authToken}`
      },
      body: JSON.stringify({ text })
    });

    const data = await response.json();

    if (!response.ok) {
      showError(data.error);
      return;
    }

    input.value = '';
    await loadComments(postId);
    showToast('Comment added!', 'success');
  } catch (error) {
    showError('Failed to add comment');
  }
}

// ============================================
// CREATE POST FUNCTIONS
// ============================================

function openCreatePostModal() {
  document.getElementById('createPostModal').classList.add('active');
}

function closeCreatePostModal() {
  document.getElementById('createPostModal').classList.remove('active');
  document.getElementById('postCaption').value = '';
  document.getElementById('postImage').value = '';
  document.getElementById('imagePreview').innerHTML = '';
}

function handleImagePreview(e) {
  const file = e.target.files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = (event) => {
    const preview = document.getElementById('imagePreview');
    preview.innerHTML = `<img src="${event.target.result}" alt="Preview">`;
  };
  reader.readAsDataURL(file);
}

async function publishPost() {
  const caption = document.getElementById('postCaption').value;
  const imageFile = document.getElementById('postImage').files[0];

  if (!caption && !imageFile) {
    showError('Please add a caption or image');
    return;
  }

  try {
    const formData = new FormData();
    if (caption) formData.append('caption', caption);
    if (imageFile) formData.append('image', imageFile);

    const response = await fetch(`${API_URL}/posts`, {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${authToken}` },
      body: formData
    });

    const data = await response.json();

    if (!response.ok) {
      showError(data.error);
      return;
    }

    closeCreatePostModal();
    await loadFeed();
    showToast('Post published!', 'success');
  } catch (error) {
    showError('Failed to publish post');
  }
}

// ============================================
// TRENDING & DISCOVERY
// ============================================

async function loadTrending() {
  try {
    const response = await fetch(`${API_URL}/trending`, {
      headers: { 'Authorization': `Bearer ${authToken}` }
    });

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.error);
    }

    // Trending is already rendered in HTML
  } catch (error) {
    console.error('Failed to load trending:', error);
  }
}

async function loadSuggestedUsers() {
  try {
    const response = await fetch(`${API_URL}/users/search?q=`, {
      headers: { 'Authorization': `Bearer ${authToken}` }
    });

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.error);
    }

    renderSuggestedUsers(data.data || []);
  } catch (error) {
    console.error('Failed to load suggested users:', error);
  }
}

function renderSuggestedUsers(users) {
  const container = document.getElementById('suggestedContainer');

  if (users.length === 0) {
    container.innerHTML = '<p style="text-align: center; color: var(--text-tertiary); font-size: 12px;">No users to suggest</p>';
    return;
  }

  container.innerHTML = users.slice(0, 5).map(user => `
    <div class="suggested-user">
      <div class="suggested-user-info">
        <div class="suggested-user-avatar">${user.full_name.substring(0, 1).toUpperCase()}</div>
        <div class="suggested-user-name">${user.full_name}</div>
      </div>
      <button class="btn-follow" onclick="followUser(${user.id})">Follow</button>
    </div>
  `).join('');
}

async function followUser(userId) {
  try {
    const response = await fetch(`${API_URL}/users/${userId}/follow`, {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${authToken}` }
    });

    const data = await response.json();

    if (!response.ok) {
      showError(data.error);
      return;
    }

    await loadUserProfile();
    showToast('User followed!', 'success');
  } catch (error) {
    showError('Failed to follow user');
  }
}

// ============================================
// SEARCH FUNCTIONS
// ============================================

async function handleSearch(e) {
  const query = e.target.value.trim();

  if (query.length < 2) return;

  try {
    const response = await fetch(`${API_URL}/users/search?q=${encodeURIComponent(query)}`, {
      headers: { 'Authorization': `Bearer ${authToken}` }
    });

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.error);
    }

    // Handle search results
    console.log('Search results:', data.data);
  } catch (error) {
    console.error('Search failed:', error);
  }
}

// ============================================
// NAVIGATION
// ============================================

function navigateTo(page) {
  console.log('Navigating to:', page);
  // Update active menu item
  document.querySelectorAll('.menu-item').forEach(item => {
    item.classList.remove('active');
  });

  // Load appropriate content based on page
  switch (page) {
    case 'home':
      loadFeed();
      break;
    case 'explore':
      loadTrending();
      break;
    case 'notifications':
      loadNotifications();
      break;
    case 'profile':
      loadUserProfile();
      break;
    case 'saved':
      loadSavedPosts();
      break;
  }
}

async function loadNotifications() {
  try {
    const response = await fetch(`${API_URL}/notifications`, {
      headers: { 'Authorization': `Bearer ${authToken}` }
    });

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.error);
    }

    console.log('Notifications:', data.data);
  } catch (error) {
    console.error('Failed to load notifications:', error);
  }
}

async function loadSavedPosts() {
  try {
    const response = await fetch(`${API_URL}/posts`, {
      headers: { 'Authorization': `Bearer ${authToken}` }
    });

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.error);
    }

    renderFeed(data.data || []);
  } catch (error) {
    console.error('Failed to load saved posts:', error);
  }
}

// ============================================
// UI HELPERS
// ============================================

function showAuthPage() {
  document.getElementById('authContainer').style.display = 'flex';
  document.getElementById('mainApp').style.display = 'none';
}

function showMainApp() {
  document.getElementById('authContainer').style.display = 'none';
  document.getElementById('mainApp').style.display = 'flex';
}

function showError(message) {
  const errorElement = document.getElementById('errorMessage');
  errorElement.textContent = message;
  errorElement.classList.add('show');

  setTimeout(() => {
    errorElement.classList.remove('show');
  }, 5000);
}

function showToast(message, type = 'info') {
  const toast = document.getElementById('toast');
  toast.textContent = message;
  toast.className = `toast show ${type}`;

  setTimeout(() => {
    toast.classList.remove('show');
  }, 3000);
}

function formatDate(dateString) {
  const date = new Date(dateString);
  const now = new Date();
  const seconds = Math.floor((now - date) / 1000);

  if (seconds < 60) return 'just now';
  if (seconds < 3600) return Math.floor(seconds / 60) + 'm ago';
  if (seconds < 86400) return Math.floor(seconds / 3600) + 'h ago';
  if (seconds < 604800) return Math.floor(seconds / 86400) + 'd ago';

  return date.toLocaleDateString();
}
