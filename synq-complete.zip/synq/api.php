<?php
/**
 * SYNQ API - Main Router
 */

require_once 'config.php';

$method = $_SERVER['REQUEST_METHOD'];
$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$path = str_replace('/api', '', $path);

// Route handling
switch (true) {
    // Auth Routes
    case preg_match('/^\/auth\/register$/', $path) && $method === 'POST':
        handleRegister();
        break;
    
    case preg_match('/^\/auth\/login$/', $path) && $method === 'POST':
        handleLogin();
        break;
    
    case preg_match('/^\/auth\/logout$/', $path) && $method === 'POST':
        handleLogout();
        break;
    
    // User Routes
    case preg_match('/^\/users\/profile$/', $path) && $method === 'GET':
        handleGetProfile();
        break;
    
    case preg_match('/^\/users\/(\d+)$/', $path, $matches) && $method === 'GET':
        handleGetUser($matches[1]);
        break;
    
    case preg_match('/^\/users\/profile$/', $path) && $method === 'PUT':
        handleUpdateProfile();
        break;
    
    case preg_match('/^\/users\/search$/', $path) && $method === 'GET':
        handleSearchUsers();
        break;
    
    // Post Routes
    case preg_match('/^\/posts$/', $path) && $method === 'GET':
        handleGetPosts();
        break;
    
    case preg_match('/^\/posts$/', $path) && $method === 'POST':
        handleCreatePost();
        break;
    
    case preg_match('/^\/posts\/(\d+)$/', $path, $matches) && $method === 'GET':
        handleGetPost($matches[1]);
        break;
    
    case preg_match('/^\/posts\/(\d+)$/', $path, $matches) && $method === 'PUT':
        handleUpdatePost($matches[1]);
        break;
    
    case preg_match('/^\/posts\/(\d+)$/', $path, $matches) && $method === 'DELETE':
        handleDeletePost($matches[1]);
        break;
    
    case preg_match('/^\/posts\/(\d+)\/like$/', $path, $matches) && $method === 'POST':
        handleLikePost($matches[1]);
        break;
    
    case preg_match('/^\/posts\/(\d+)\/unlike$/', $path, $matches) && $method === 'POST':
        handleUnlikePost($matches[1]);
        break;
    
    // Comment Routes
    case preg_match('/^\/posts\/(\d+)\/comments$/', $path, $matches) && $method === 'GET':
        handleGetComments($matches[1]);
        break;
    
    case preg_match('/^\/posts\/(\d+)\/comments$/', $path, $matches) && $method === 'POST':
        handleCreateComment($matches[1]);
        break;
    
    case preg_match('/^\/comments\/(\d+)$/', $path, $matches) && $method === 'DELETE':
        handleDeleteComment($matches[1]);
        break;
    
    // Follow Routes
    case preg_match('/^\/users\/(\d+)\/follow$/', $path, $matches) && $method === 'POST':
        handleFollowUser($matches[1]);
        break;
    
    case preg_match('/^\/users\/(\d+)\/unfollow$/', $path, $matches) && $method === 'POST':
        handleUnfollowUser($matches[1]);
        break;
    
    case preg_match('/^\/users\/(\d+)\/followers$/', $path, $matches) && $method === 'GET':
        handleGetFollowers($matches[1]);
        break;
    
    case preg_match('/^\/users\/(\d+)\/following$/', $path, $matches) && $method === 'GET':
        handleGetFollowing($matches[1]);
        break;
    
    // Notification Routes
    case preg_match('/^\/notifications$/', $path) && $method === 'GET':
        handleGetNotifications();
        break;
    
    case preg_match('/^\/notifications\/(\d+)\/read$/', $path, $matches) && $method === 'PUT':
        handleMarkNotificationRead($matches[1]);
        break;
    
    // Feed Routes
    case preg_match('/^\/feed$/', $path) && $method === 'GET':
        handleGetFeed();
        break;
    
    case preg_match('/^\/trending$/', $path) && $method === 'GET':
        handleGetTrending();
        break;
    
    default:
        error('Endpoint not found', 404);
}

// ============================================
// AUTH HANDLERS
// ============================================

function handleRegister() {
    global $pdo;
    
    $email = sanitizeInput(getInput('email'));
    $username = sanitizeInput(getInput('username'));
    $password = getInput('password');
    $full_name = sanitizeInput(getInput('full_name'));
    
    if (!validateEmail($email)) {
        error('Invalid email');
    }
    
    if (!validateUsername($username)) {
        error('Username must be 3-50 characters, alphanumeric and underscore only');
    }
    
    if (strlen($password) < PASSWORD_MIN_LENGTH) {
        error('Password must be at least ' . PASSWORD_MIN_LENGTH . ' characters');
    }
    
    try {
        $stmt = $pdo->prepare('SELECT id FROM users WHERE email = ? OR username = ?');
        $stmt->execute([$email, $username]);
        
        if ($stmt->fetch()) {
            error('Email or username already exists');
        }
        
        $stmt = $pdo->prepare('INSERT INTO users (email, username, password, full_name) VALUES (?, ?, ?, ?)');
        $stmt->execute([$email, $username, hashPassword($password), $full_name]);
        
        $user_id = $pdo->lastInsertId();
        $token = generateToken($user_id);
        
        success(['token' => $token, 'user_id' => $user_id], 'Registration successful', 201);
    } catch (Exception $e) {
        error('Registration failed', 500);
    }
}

function handleLogin() {
    global $pdo;
    
    $email = sanitizeInput(getInput('email'));
    $password = getInput('password');
    
    try {
        $stmt = $pdo->prepare('SELECT id, password FROM users WHERE email = ?');
        $stmt->execute([$email]);
        $user = $stmt->fetch();
        
        if (!$user || !verifyPassword($password, $user['password'])) {
            error('Invalid email or password');
        }
        
        $token = generateToken($user['id']);
        success(['token' => $token, 'user_id' => $user['id']], 'Login successful');
    } catch (Exception $e) {
        error('Login failed', 500);
    }
}

function handleLogout() {
    success([], 'Logged out successfully');
}

// ============================================
// USER HANDLERS
// ============================================

function handleGetProfile() {
    global $pdo;
    
    $user_id = getAuthUser();
    if (!$user_id) {
        error('Unauthorized', 401);
    }
    
    try {
        $stmt = $pdo->prepare('SELECT id, username, email, full_name, bio, avatar_url, cover_url, website, location, followers_count, following_count, posts_count, is_verified FROM users WHERE id = ?');
        $stmt->execute([$user_id]);
        $user = $stmt->fetch();
        
        if (!$user) {
            error('User not found', 404);
        }
        
        success($user);
    } catch (Exception $e) {
        error('Failed to fetch profile', 500);
    }
}

function handleGetUser($user_id) {
    global $pdo;
    
    try {
        $stmt = $pdo->prepare('SELECT id, username, full_name, bio, avatar_url, cover_url, website, location, followers_count, following_count, posts_count, is_verified, created_at FROM users WHERE id = ?');
        $stmt->execute([$user_id]);
        $user = $stmt->fetch();
        
        if (!$user) {
            error('User not found', 404);
        }
        
        success($user);
    } catch (Exception $e) {
        error('Failed to fetch user', 500);
    }
}

function handleUpdateProfile() {
    global $pdo;
    
    $user_id = getAuthUser();
    if (!$user_id) {
        error('Unauthorized', 401);
    }
    
    $full_name = sanitizeInput(getInput('full_name'));
    $bio = sanitizeInput(getInput('bio'));
    $website = sanitizeInput(getInput('website'));
    $location = sanitizeInput(getInput('location'));
    
    try {
        $stmt = $pdo->prepare('UPDATE users SET full_name = ?, bio = ?, website = ?, location = ? WHERE id = ?');
        $stmt->execute([$full_name, $bio, $website, $location, $user_id]);
        
        success([], 'Profile updated successfully');
    } catch (Exception $e) {
        error('Failed to update profile', 500);
    }
}

function handleSearchUsers() {
    global $pdo;
    
    $query = sanitizeInput($_GET['q'] ?? '');
    
    if (strlen($query) < 2) {
        error('Search query must be at least 2 characters');
    }
    
    try {
        $stmt = $pdo->prepare('SELECT id, username, full_name, avatar_url, is_verified FROM users WHERE username LIKE ? OR full_name LIKE ? LIMIT 20');
        $stmt->execute(["%$query%", "%$query%"]);
        $users = $stmt->fetchAll();
        
        success($users);
    } catch (Exception $e) {
        error('Search failed', 500);
    }
}

// ============================================
// POST HANDLERS
// ============================================

function handleGetPosts() {
    global $pdo;
    
    $page = max(1, intval($_GET['page'] ?? 1));
    $offset = ($page - 1) * POSTS_PER_PAGE;
    
    try {
        $stmt = $pdo->prepare('
            SELECT p.id, p.user_id, p.caption, p.image_url, p.likes_count, p.comments_count, p.created_at,
                   u.username, u.full_name, u.avatar_url
            FROM posts p
            JOIN users u ON p.user_id = u.id
            ORDER BY p.created_at DESC
            LIMIT ? OFFSET ?
        ');
        $stmt->execute([POSTS_PER_PAGE, $offset]);
        $posts = $stmt->fetchAll();
        
        success($posts);
    } catch (Exception $e) {
        error('Failed to fetch posts', 500);
    }
}

function handleCreatePost() {
    global $pdo;
    
    $user_id = getAuthUser();
    if (!$user_id) {
        error('Unauthorized', 401);
    }
    
    $caption = sanitizeInput(getInput('caption'));
    $image_url = null;
    
    if (isset($_FILES['image'])) {
        $image_url = uploadFile($_FILES['image']);
    }
    
    if (!$caption && !$image_url) {
        error('Post must have caption or image');
    }
    
    try {
        $stmt = $pdo->prepare('INSERT INTO posts (user_id, caption, image_url) VALUES (?, ?, ?)');
        $stmt->execute([$user_id, $caption ?: null, $image_url]);
        
        $post_id = $pdo->lastInsertId();
        
        // Update user posts count
        $pdo->prepare('UPDATE users SET posts_count = posts_count + 1 WHERE id = ?')->execute([$user_id]);
        
        success(['id' => $post_id], 'Post created successfully', 201);
    } catch (Exception $e) {
        error('Failed to create post', 500);
    }
}

function handleGetPost($post_id) {
    global $pdo;
    
    try {
        $stmt = $pdo->prepare('
            SELECT p.id, p.user_id, p.caption, p.image_url, p.likes_count, p.comments_count, p.created_at,
                   u.username, u.full_name, u.avatar_url
            FROM posts p
            JOIN users u ON p.user_id = u.id
            WHERE p.id = ?
        ');
        $stmt->execute([$post_id]);
        $post = $stmt->fetch();
        
        if (!$post) {
            error('Post not found', 404);
        }
        
        success($post);
    } catch (Exception $e) {
        error('Failed to fetch post', 500);
    }
}

function handleUpdatePost($post_id) {
    global $pdo;
    
    $user_id = getAuthUser();
    if (!$user_id) {
        error('Unauthorized', 401);
    }
    
    $caption = sanitizeInput(getInput('caption'));
    
    try {
        // Check ownership
        $stmt = $pdo->prepare('SELECT user_id FROM posts WHERE id = ?');
        $stmt->execute([$post_id]);
        $post = $stmt->fetch();
        
        if (!$post || $post['user_id'] != $user_id) {
            error('Unauthorized', 403);
        }
        
        $stmt = $pdo->prepare('UPDATE posts SET caption = ? WHERE id = ?');
        $stmt->execute([$caption, $post_id]);
        
        success([], 'Post updated successfully');
    } catch (Exception $e) {
        error('Failed to update post', 500);
    }
}

function handleDeletePost($post_id) {
    global $pdo;
    
    $user_id = getAuthUser();
    if (!$user_id) {
        error('Unauthorized', 401);
    }
    
    try {
        // Check ownership
        $stmt = $pdo->prepare('SELECT user_id FROM posts WHERE id = ?');
        $stmt->execute([$post_id]);
        $post = $stmt->fetch();
        
        if (!$post || $post['user_id'] != $user_id) {
            error('Unauthorized', 403);
        }
        
        $pdo->prepare('DELETE FROM posts WHERE id = ?')->execute([$post_id]);
        $pdo->prepare('UPDATE users SET posts_count = posts_count - 1 WHERE id = ?')->execute([$user_id]);
        
        success([], 'Post deleted successfully');
    } catch (Exception $e) {
        error('Failed to delete post', 500);
    }
}

function handleLikePost($post_id) {
    global $pdo;
    
    $user_id = getAuthUser();
    if (!$user_id) {
        error('Unauthorized', 401);
    }
    
    try {
        $stmt = $pdo->prepare('INSERT IGNORE INTO likes (user_id, post_id) VALUES (?, ?)');
        $stmt->execute([$user_id, $post_id]);
        
        $pdo->prepare('UPDATE posts SET likes_count = likes_count + 1 WHERE id = ? AND likes_count = (SELECT COUNT(*) - 1 FROM likes WHERE post_id = ?)')->execute([$post_id, $post_id]);
        
        success([], 'Post liked');
    } catch (Exception $e) {
        error('Failed to like post', 500);
    }
}

function handleUnlikePost($post_id) {
    global $pdo;
    
    $user_id = getAuthUser();
    if (!$user_id) {
        error('Unauthorized', 401);
    }
    
    try {
        $pdo->prepare('DELETE FROM likes WHERE user_id = ? AND post_id = ?')->execute([$user_id, $post_id]);
        $pdo->prepare('UPDATE posts SET likes_count = GREATEST(likes_count - 1, 0) WHERE id = ?')->execute([$post_id]);
        
        success([], 'Post unliked');
    } catch (Exception $e) {
        error('Failed to unlike post', 500);
    }
}

// ============================================
// COMMENT HANDLERS
// ============================================

function handleGetComments($post_id) {
    global $pdo;
    
    $page = max(1, intval($_GET['page'] ?? 1));
    $offset = ($page - 1) * COMMENTS_PER_PAGE;
    
    try {
        $stmt = $pdo->prepare('
            SELECT c.id, c.user_id, c.text, c.likes_count, c.created_at,
                   u.username, u.full_name, u.avatar_url
            FROM comments c
            JOIN users u ON c.user_id = u.id
            WHERE c.post_id = ?
            ORDER BY c.created_at DESC
            LIMIT ? OFFSET ?
        ');
        $stmt->execute([$post_id, COMMENTS_PER_PAGE, $offset]);
        $comments = $stmt->fetchAll();
        
        success($comments);
    } catch (Exception $e) {
        error('Failed to fetch comments', 500);
    }
}

function handleCreateComment($post_id) {
    global $pdo;
    
    $user_id = getAuthUser();
    if (!$user_id) {
        error('Unauthorized', 401);
    }
    
    $text = sanitizeInput(getInput('text'));
    
    if (empty($text)) {
        error('Comment cannot be empty');
    }
    
    try {
        $stmt = $pdo->prepare('INSERT INTO comments (post_id, user_id, text) VALUES (?, ?, ?)');
        $stmt->execute([$post_id, $user_id, $text]);
        
        $pdo->prepare('UPDATE posts SET comments_count = comments_count + 1 WHERE id = ?')->execute([$post_id]);
        
        success(['id' => $pdo->lastInsertId()], 'Comment created', 201);
    } catch (Exception $e) {
        error('Failed to create comment', 500);
    }
}

function handleDeleteComment($comment_id) {
    global $pdo;
    
    $user_id = getAuthUser();
    if (!$user_id) {
        error('Unauthorized', 401);
    }
    
    try {
        $stmt = $pdo->prepare('SELECT user_id, post_id FROM comments WHERE id = ?');
        $stmt->execute([$comment_id]);
        $comment = $stmt->fetch();
        
        if (!$comment || $comment['user_id'] != $user_id) {
            error('Unauthorized', 403);
        }
        
        $pdo->prepare('DELETE FROM comments WHERE id = ?')->execute([$comment_id]);
        $pdo->prepare('UPDATE posts SET comments_count = GREATEST(comments_count - 1, 0) WHERE id = ?')->execute([$comment['post_id']]);
        
        success([], 'Comment deleted');
    } catch (Exception $e) {
        error('Failed to delete comment', 500);
    }
}

// ============================================
// FOLLOW HANDLERS
// ============================================

function handleFollowUser($following_id) {
    global $pdo;
    
    $user_id = getAuthUser();
    if (!$user_id) {
        error('Unauthorized', 401);
    }
    
    if ($user_id == $following_id) {
        error('Cannot follow yourself');
    }
    
    try {
        $stmt = $pdo->prepare('INSERT IGNORE INTO follows (follower_id, following_id) VALUES (?, ?)');
        $stmt->execute([$user_id, $following_id]);
        
        $pdo->prepare('UPDATE users SET followers_count = followers_count + 1 WHERE id = ?')->execute([$following_id]);
        $pdo->prepare('UPDATE users SET following_count = following_count + 1 WHERE id = ?')->execute([$user_id]);
        
        success([], 'User followed');
    } catch (Exception $e) {
        error('Failed to follow user', 500);
    }
}

function handleUnfollowUser($following_id) {
    global $pdo;
    
    $user_id = getAuthUser();
    if (!$user_id) {
        error('Unauthorized', 401);
    }
    
    try {
        $pdo->prepare('DELETE FROM follows WHERE follower_id = ? AND following_id = ?')->execute([$user_id, $following_id]);
        $pdo->prepare('UPDATE users SET followers_count = GREATEST(followers_count - 1, 0) WHERE id = ?')->execute([$following_id]);
        $pdo->prepare('UPDATE users SET following_count = GREATEST(following_count - 1, 0) WHERE id = ?')->execute([$user_id]);
        
        success([], 'User unfollowed');
    } catch (Exception $e) {
        error('Failed to unfollow user', 500);
    }
}

function handleGetFollowers($user_id) {
    global $pdo;
    
    try {
        $stmt = $pdo->prepare('
            SELECT u.id, u.username, u.full_name, u.avatar_url, u.is_verified
            FROM users u
            JOIN follows f ON u.id = f.follower_id
            WHERE f.following_id = ?
            ORDER BY f.created_at DESC
        ');
        $stmt->execute([$user_id]);
        $followers = $stmt->fetchAll();
        
        success($followers);
    } catch (Exception $e) {
        error('Failed to fetch followers', 500);
    }
}

function handleGetFollowing($user_id) {
    global $pdo;
    
    try {
        $stmt = $pdo->prepare('
            SELECT u.id, u.username, u.full_name, u.avatar_url, u.is_verified
            FROM users u
            JOIN follows f ON u.id = f.following_id
            WHERE f.follower_id = ?
            ORDER BY f.created_at DESC
        ');
        $stmt->execute([$user_id]);
        $following = $stmt->fetchAll();
        
        success($following);
    } catch (Exception $e) {
        error('Failed to fetch following', 500);
    }
}

// ============================================
// NOTIFICATION HANDLERS
// ============================================

function handleGetNotifications() {
    global $pdo;
    
    $user_id = getAuthUser();
    if (!$user_id) {
        error('Unauthorized', 401);
    }
    
    try {
        $stmt = $pdo->prepare('
            SELECT n.id, n.from_user_id, n.type, n.message, n.is_read, n.created_at,
                   u.username, u.full_name, u.avatar_url
            FROM notifications n
            LEFT JOIN users u ON n.from_user_id = u.id
            WHERE n.user_id = ?
            ORDER BY n.created_at DESC
            LIMIT 50
        ');
        $stmt->execute([$user_id]);
        $notifications = $stmt->fetchAll();
        
        success($notifications);
    } catch (Exception $e) {
        error('Failed to fetch notifications', 500);
    }
}

function handleMarkNotificationRead($notification_id) {
    global $pdo;
    
    $user_id = getAuthUser();
    if (!$user_id) {
        error('Unauthorized', 401);
    }
    
    try {
        $pdo->prepare('UPDATE notifications SET is_read = 1 WHERE id = ? AND user_id = ?')->execute([$notification_id, $user_id]);
        success([], 'Notification marked as read');
    } catch (Exception $e) {
        error('Failed to mark notification', 500);
    }
}

// ============================================
// FEED HANDLERS
// ============================================

function handleGetFeed() {
    global $pdo;
    
    $user_id = getAuthUser();
    if (!$user_id) {
        error('Unauthorized', 401);
    }
    
    $page = max(1, intval($_GET['page'] ?? 1));
    $offset = ($page - 1) * POSTS_PER_PAGE;
    
    try {
        $stmt = $pdo->prepare('
            SELECT p.id, p.user_id, p.caption, p.image_url, p.likes_count, p.comments_count, p.created_at,
                   u.username, u.full_name, u.avatar_url
            FROM posts p
            JOIN users u ON p.user_id = u.id
            JOIN follows f ON p.user_id = f.following_id
            WHERE f.follower_id = ?
            ORDER BY p.created_at DESC
            LIMIT ? OFFSET ?
        ');
        $stmt->execute([$user_id, POSTS_PER_PAGE, $offset]);
        $posts = $stmt->fetchAll();
        
        success($posts);
    } catch (Exception $e) {
        error('Failed to fetch feed', 500);
    }
}

function handleGetTrending() {
    global $pdo;
    
    try {
        $stmt = $pdo->prepare('
            SELECT p.id, p.user_id, p.caption, p.image_url, p.likes_count, p.comments_count, p.created_at,
                   u.username, u.full_name, u.avatar_url,
                   (p.likes_count + p.comments_count * 2 + p.shares_count * 3) as engagement_score
            FROM posts p
            JOIN users u ON p.user_id = u.id
            WHERE p.created_at > DATE_SUB(NOW(), INTERVAL 7 DAY)
            ORDER BY engagement_score DESC
            LIMIT 20
        ');
        $stmt->execute();
        $posts = $stmt->fetchAll();
        
        success($posts);
    } catch (Exception $e) {
        error('Failed to fetch trending', 500);
    }
}

?>
