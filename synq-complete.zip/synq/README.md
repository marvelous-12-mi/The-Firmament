# Synq - Next Generation Social Media Platform

A modern, feature-rich social media platform built with PHP, JavaScript, HTML, and MySQL. Synq provides a complete social networking experience with posts, comments, likes, follows, and real-time interactions.

## 🚀 Features

### Core Features
- **User Authentication** - Secure signup and login with password hashing
- **User Profiles** - Customizable profiles with bio, avatar, and stats
- **Posts** - Create, edit, and delete posts with image support
- **Likes** - Like and unlike posts with real-time counts
- **Comments** - Add comments to posts with nested replies
- **Follow System** - Follow and unfollow users to build your network
- **Feed** - Personalized feed showing posts from followed users
- **Trending** - Discover trending posts and hashtags
- **Notifications** - Real-time notifications for interactions
- **Search** - Search for users and posts
- **Saved Posts** - Save posts for later viewing

### Technical Features
- **RESTful API** - Complete REST API for all operations
- **JWT Authentication** - Secure token-based authentication
- **Database Optimization** - Indexed queries for performance
- **Row-Level Security** - User data privacy and protection
- **Responsive Design** - Works on desktop, tablet, and mobile
- **Real-time Updates** - Instant feedback on user actions
- **Error Handling** - Comprehensive error messages and validation

## 📋 Requirements

- PHP 7.4 or higher
- MySQL 5.7 or higher
- Modern web browser (Chrome, Firefox, Safari, Edge)
- 50MB disk space

## 🔧 Installation

### 1. Database Setup

```bash
# Import the database schema
mysql -u root -p < database.sql

# Or manually:
# 1. Open phpMyAdmin or MySQL client
# 2. Create database: CREATE DATABASE synq_db;
# 3. Import database.sql file
```

### 2. Configuration

Edit `config.php` and update:

```php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', 'your_password');
define('DB_NAME', 'synq_db');
define('JWT_SECRET', 'your-super-secret-key');
define('APP_URL', 'http://your-domain.com');
```

### 3. File Permissions

```bash
# Create uploads directory
mkdir -p uploads
chmod 755 uploads

# Set proper permissions
chmod 644 config.php
chmod 644 api.php
chmod 644 index.html
chmod 644 styles.css
chmod 644 app.js
```

### 4. Web Server Setup

#### Apache (.htaccess)
```apache
<IfModule mod_rewrite.c>
    RewriteEngine On
    RewriteBase /
    RewriteRule ^api/(.*)$ api.php [QSA,L]
    RewriteRule ^index\.html$ - [L]
    RewriteCond %{REQUEST_FILENAME} !-f
    RewriteCond %{REQUEST_FILENAME} !-d
    RewriteRule . /index.html [L]
</IfModule>
```

#### Nginx
```nginx
location /api/ {
    rewrite ^/api/(.*)$ /api.php last;
}

location / {
    try_files $uri $uri/ /index.html;
}
```

### 5. Start Development Server

```bash
# Using PHP built-in server
php -S localhost:8000

# Access at http://localhost:8000
```

## 📚 API Documentation

### Authentication Endpoints

#### Register
```
POST /api/auth/register
Content-Type: application/json

{
  "email": "user@example.com",
  "username": "username",
  "password": "password123",
  "full_name": "Full Name"
}

Response:
{
  "success": true,
  "data": {
    "token": "eyJ...",
    "user_id": 1
  }
}
```

#### Login
```
POST /api/auth/login
Content-Type: application/json

{
  "email": "user@example.com",
  "password": "password123"
}

Response:
{
  "success": true,
  "data": {
    "token": "eyJ...",
    "user_id": 1
  }
}
```

### User Endpoints

#### Get Profile
```
GET /api/users/profile
Authorization: Bearer {token}

Response:
{
  "success": true,
  "data": {
    "id": 1,
    "username": "username",
    "email": "user@example.com",
    "full_name": "Full Name",
    "bio": "Bio text",
    "followers_count": 100,
    "following_count": 50,
    "posts_count": 25
  }
}
```

#### Update Profile
```
PUT /api/users/profile
Authorization: Bearer {token}
Content-Type: application/json

{
  "full_name": "New Name",
  "bio": "New bio",
  "website": "https://example.com",
  "location": "City, Country"
}
```

#### Search Users
```
GET /api/users/search?q=query
Authorization: Bearer {token}

Response:
{
  "success": true,
  "data": [
    {
      "id": 2,
      "username": "john_doe",
      "full_name": "John Doe",
      "avatar_url": "/uploads/avatar.jpg",
      "is_verified": false
    }
  ]
}
```

### Post Endpoints

#### Get Posts
```
GET /api/posts?page=1
Authorization: Bearer {token}

Response:
{
  "success": true,
  "data": [
    {
      "id": 1,
      "user_id": 1,
      "caption": "Post caption",
      "image_url": "/uploads/image.jpg",
      "likes_count": 10,
      "comments_count": 5,
      "created_at": "2024-01-01T12:00:00Z",
      "username": "username",
      "full_name": "Full Name",
      "avatar_url": "/uploads/avatar.jpg"
    }
  ]
}
```

#### Create Post
```
POST /api/posts
Authorization: Bearer {token}
Content-Type: multipart/form-data

caption: "Post caption"
image: <file>

Response:
{
  "success": true,
  "data": {
    "id": 1
  }
}
```

#### Like Post
```
POST /api/posts/{id}/like
Authorization: Bearer {token}

Response:
{
  "success": true,
  "message": "Post liked"
}
```

### Comment Endpoints

#### Get Comments
```
GET /api/posts/{id}/comments?page=1
Authorization: Bearer {token}

Response:
{
  "success": true,
  "data": [
    {
      "id": 1,
      "user_id": 1,
      "text": "Comment text",
      "likes_count": 2,
      "created_at": "2024-01-01T12:00:00Z",
      "username": "username",
      "full_name": "Full Name",
      "avatar_url": "/uploads/avatar.jpg"
    }
  ]
}
```

#### Add Comment
```
POST /api/posts/{id}/comments
Authorization: Bearer {token}
Content-Type: application/json

{
  "text": "Comment text"
}

Response:
{
  "success": true,
  "data": {
    "id": 1
  }
}
```

### Follow Endpoints

#### Follow User
```
POST /api/users/{id}/follow
Authorization: Bearer {token}

Response:
{
  "success": true,
  "message": "User followed"
}
```

#### Get Followers
```
GET /api/users/{id}/followers
Authorization: Bearer {token}

Response:
{
  "success": true,
  "data": [
    {
      "id": 1,
      "username": "username",
      "full_name": "Full Name",
      "avatar_url": "/uploads/avatar.jpg",
      "is_verified": false
    }
  ]
}
```

### Feed Endpoints

#### Get Personal Feed
```
GET /api/feed?page=1
Authorization: Bearer {token}

Response:
{
  "success": true,
  "data": [
    {
      "id": 1,
      "user_id": 1,
      "caption": "Post caption",
      "image_url": "/uploads/image.jpg",
      "likes_count": 10,
      "comments_count": 5,
      "created_at": "2024-01-01T12:00:00Z",
      "username": "username",
      "full_name": "Full Name",
      "avatar_url": "/uploads/avatar.jpg"
    }
  ]
}
```

#### Get Trending Posts
```
GET /api/trending
Authorization: Bearer {token}

Response:
{
  "success": true,
  "data": [...]
}
```

## 🗄️ Database Schema

### Users Table
- `id` - Primary key
- `username` - Unique username
- `email` - Unique email address
- `password` - Hashed password
- `full_name` - User's full name
- `bio` - User biography
- `avatar_url` - Profile picture URL
- `followers_count` - Number of followers
- `following_count` - Number of following
- `posts_count` - Number of posts

### Posts Table
- `id` - Primary key
- `user_id` - Foreign key to users
- `caption` - Post caption/text
- `image_url` - Post image URL
- `likes_count` - Number of likes
- `comments_count` - Number of comments
- `created_at` - Creation timestamp

### Comments Table
- `id` - Primary key
- `post_id` - Foreign key to posts
- `user_id` - Foreign key to users
- `text` - Comment text
- `likes_count` - Number of likes
- `created_at` - Creation timestamp

### Likes Table
- `id` - Primary key
- `user_id` - Foreign key to users
- `post_id` - Foreign key to posts (nullable)
- `comment_id` - Foreign key to comments (nullable)

### Follows Table
- `id` - Primary key
- `follower_id` - Foreign key to users
- `following_id` - Foreign key to users

## 🚀 Deployment

### Heroku
```bash
git init
git add .
git commit -m "Initial commit"
heroku create your-app-name
git push heroku main
```

### DigitalOcean
1. Create a Droplet with PHP and MySQL
2. Clone the repository
3. Configure database and web server
4. Set up SSL with Let's Encrypt

### AWS
1. Create EC2 instance with PHP/MySQL
2. Configure security groups
3. Set up RDS for database
4. Deploy application

### Shared Hosting
1. Upload files via FTP
2. Create database via cPanel
3. Import database.sql
4. Update config.php with hosting credentials

## 🔐 Security Best Practices

1. **Change JWT_SECRET** - Use a strong, unique secret key
2. **Enable HTTPS** - Always use SSL/TLS in production
3. **Update Dependencies** - Keep PHP and MySQL updated
4. **Validate Input** - All user input is validated server-side
5. **SQL Injection Prevention** - Using prepared statements
6. **XSS Protection** - HTML escaping and content validation
7. **CSRF Protection** - Implement token-based CSRF protection
8. **Rate Limiting** - Implement rate limiting on API endpoints
9. **Backup Database** - Regular automated backups
10. **Monitor Logs** - Check error logs regularly

## 📱 Browser Support

- Chrome 90+
- Firefox 88+
- Safari 14+
- Edge 90+
- Mobile browsers (iOS Safari, Chrome Mobile)

## 🤝 Contributing

Contributions are welcome! Please follow these steps:

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit changes (`git commit -m 'Add amazing feature'`)
4. Push to branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 📄 License

This project is licensed under the MIT License - see LICENSE file for details.

## 🆘 Support

For issues and questions:
- Open an issue on GitHub
- Check existing documentation
- Review API documentation
- Contact support team

## 🎯 Roadmap

- [ ] Video post support
- [ ] Live streaming
- [ ] Stories feature
- [ ] Direct messaging
- [ ] User verification system
- [ ] Content moderation
- [ ] Advanced analytics
- [ ] Mobile app (iOS/Android)
- [ ] Dark mode toggle
- [ ] Multi-language support

## 📊 Performance

- Average page load: < 2 seconds
- API response time: < 200ms
- Database queries optimized with indexes
- Caching strategy for frequently accessed data
- CDN ready for static assets

## 🎨 Customization

### Change Primary Color
Edit `styles.css`:
```css
:root {
  --primary: #667eea; /* Change this */
  --secondary: #764ba2;
  --accent: #f093fb;
}
```

### Change App Name
Edit `config.php`:
```php
define('APP_NAME', 'Your App Name');
```

Edit `index.html`:
```html
<title>Your App Name - Social Media</title>
```

## 📈 Analytics

Track user engagement with:
- Post creation rate
- User growth
- Engagement metrics
- Popular content
- User retention

## 🔄 Version History

### v1.0.0 (Current)
- Initial release
- Core social features
- User authentication
- Post management
- Comment system
- Follow system

---

**Made with ❤️ by Synq Team**

For more information, visit [synq.app](https://synq.app)
