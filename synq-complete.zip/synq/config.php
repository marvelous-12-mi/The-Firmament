<?php
/**
 * SYNQ - Social Media Platform
 * Configuration File
 */

// Database Configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'synq_db');

// Application Settings
define('APP_NAME', 'Synq');
define('APP_URL', 'http://localhost:8000');
define('APP_ENV', 'development');

// Security
define('JWT_SECRET', 'your-super-secret-jwt-key-change-this-in-production');
define('SESSION_TIMEOUT', 86400); // 24 hours
define('PASSWORD_MIN_LENGTH', 8);

// File Upload
define('MAX_UPLOAD_SIZE', 5242880); // 5MB
define('ALLOWED_EXTENSIONS', ['jpg', 'jpeg', 'png', 'gif', 'webp']);
define('UPLOAD_DIR', __DIR__ . '/uploads/');

// Pagination
define('POSTS_PER_PAGE', 10);
define('USERS_PER_PAGE', 20);
define('COMMENTS_PER_PAGE', 10);

// API Response
define('API_VERSION', '1.0.0');

// Error Reporting
if (APP_ENV === 'development') {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
} else {
    error_reporting(0);
    ini_set('display_errors', 0);
}

// Headers
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Create uploads directory if it doesn't exist
if (!is_dir(UPLOAD_DIR)) {
    mkdir(UPLOAD_DIR, 0755, true);
}

// Database Connection
try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]
    );
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Database connection failed']);
    exit();
}

// Helper Functions
function response($data, $status = 200) {
    http_response_code($status);
    echo json_encode($data);
    exit();
}

function error($message, $status = 400) {
    response(['error' => $message], $status);
}

function success($data, $message = 'Success', $status = 200) {
    response(['success' => true, 'message' => $message, 'data' => $data], $status);
}

function getAuthUser() {
    $headers = getallheaders();
    $auth = isset($headers['Authorization']) ? $headers['Authorization'] : '';
    
    if (empty($auth)) {
        return null;
    }
    
    $token = str_replace('Bearer ', '', $auth);
    $decoded = json_decode(base64_decode($token), true);
    
    return $decoded['user_id'] ?? null;
}

function hashPassword($password) {
    return password_hash($password, PASSWORD_BCRYPT);
}

function verifyPassword($password, $hash) {
    return password_verify($password, $hash);
}

function generateToken($userId) {
    $payload = [
        'user_id' => $userId,
        'iat' => time(),
        'exp' => time() + SESSION_TIMEOUT
    ];
    
    return base64_encode(json_encode($payload));
}

function validateEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

function validateUsername($username) {
    return preg_match('/^[a-zA-Z0-9_]{3,50}$/', $username);
}

function sanitizeInput($input) {
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}

function getInput($key, $default = null) {
    $input = json_decode(file_get_contents('php://input'), true) ?? [];
    return $input[$key] ?? $default;
}

function uploadFile($file) {
    if (!isset($file['tmp_name']) || !is_uploaded_file($file['tmp_name'])) {
        return null;
    }
    
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    
    if (!in_array($ext, ALLOWED_EXTENSIONS)) {
        return null;
    }
    
    if ($file['size'] > MAX_UPLOAD_SIZE) {
        return null;
    }
    
    $filename = uniqid() . '.' . $ext;
    $filepath = UPLOAD_DIR . $filename;
    
    if (move_uploaded_file($file['tmp_name'], $filepath)) {
        return '/uploads/' . $filename;
    }
    
    return null;
}

function timeAgo($date) {
    $timestamp = strtotime($date);
    $time = time() - $timestamp;
    
    $periods = [
        31536000 => 'year',
        2592000 => 'month',
        604800 => 'week',
        86400 => 'day',
        3600 => 'hour',
        60 => 'minute',
        1 => 'second'
    ];
    
    foreach ($periods as $seconds => $label) {
        $interval = floor($time / $seconds);
        if ($interval >= 1) {
            return $interval . ' ' . $label . ($interval > 1 ? 's' : '') . ' ago';
        }
    }
    
    return 'just now';
}

?>
