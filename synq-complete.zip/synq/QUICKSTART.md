# Synq - Quick Start Guide

Get Synq up and running in 5 minutes!

## ⚡ 5-Minute Setup

### Step 1: Extract Files (30 seconds)
```bash
unzip synq-complete.zip
cd synq
```

### Step 2: Create Database (1 minute)
```bash
# Using MySQL command line
mysql -u root -p < database.sql

# Or using phpMyAdmin:
# 1. Create new database: synq_db
# 2. Import database.sql file
```

### Step 3: Configure Application (1 minute)
Edit `config.php`:
```php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', 'your_password');
define('DB_NAME', 'synq_db');
define('JWT_SECRET', 'change-this-to-random-string');
```

### Step 4: Start Server (1 minute)
```bash
# Using PHP built-in server
php -S localhost:8000

# Or use your web server (Apache/Nginx)
```

### Step 5: Access Application (30 seconds)
Open browser and go to: `http://localhost:8000`

## 🎯 First Steps

1. **Create Account**
   - Click "Create Account"
   - Enter email, username, password
   - Click "Create Account"

2. **Create Your First Post**
   - Click "What's on your mind?"
   - Add caption and/or image
   - Click "Publish"

3. **Explore & Connect**
   - View other users in "Suggested For You"
   - Click "Follow" to follow users
   - Like and comment on posts

## 🔧 Configuration Options

### Change App Name
Edit `index.html` and `config.php`:
```php
define('APP_NAME', 'Your App Name');
```

### Change Primary Color
Edit `styles.css`:
```css
:root {
  --primary: #667eea;      /* Change this */
  --secondary: #764ba2;
  --accent: #f093fb;
}
```

### Enable Debug Mode
Edit `config.php`:
```php
define('APP_ENV', 'development');  // Shows detailed errors
```

## 📁 File Structure

```
synq/
├── index.html          # Main HTML file
├── styles.css          # CSS styles
├── app.js              # JavaScript logic
├── api.php             # API endpoints
├── config.php          # Configuration
├── database.sql        # Database schema
├── .htaccess           # Apache routing
├── uploads/            # User uploads (auto-created)
├── README.md           # Full documentation
├── DEPLOYMENT.md       # Deployment guide
└── QUICKSTART.md       # This file
```

## 🚀 Deployment

### To Heroku
```bash
git init
git add .
git commit -m "Initial commit"
heroku create your-app-name
git push heroku main
```

### To Shared Hosting
1. Upload files via FTP to public_html
2. Create database via cPanel
3. Import database.sql
4. Update config.php

### To DigitalOcean
See DEPLOYMENT.md for detailed instructions

## 🐛 Troubleshooting

### "Database connection failed"
- Check DB_HOST, DB_USER, DB_PASS in config.php
- Verify MySQL is running
- Check database exists

### "404 Not Found"
- Ensure .htaccess is present
- Check mod_rewrite is enabled
- Verify web server configuration

### "Cannot create uploads directory"
- Check file permissions
- Run: `chmod 755 uploads`
- Ensure directory is writable

### "Login not working"
- Clear browser cache
- Check database connection
- Verify JWT_SECRET is set

## 📚 API Examples

### Register User
```bash
curl -X POST http://localhost:8000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "email": "user@example.com",
    "username": "username",
    "password": "password123",
    "full_name": "Full Name"
  }'
```

### Create Post
```bash
curl -X POST http://localhost:8000/api/posts \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -F "caption=My first post" \
  -F "image=@image.jpg"
```

### Get Feed
```bash
curl -X GET http://localhost:8000/api/feed \
  -H "Authorization: Bearer YOUR_TOKEN"
```

## 🔐 Security Reminders

1. **Change JWT_SECRET** - Use a strong, random value
2. **Update Credentials** - Change default database password
3. **Enable HTTPS** - Use SSL in production
4. **File Permissions** - Set proper permissions (644/755)
5. **Regular Backups** - Backup database regularly

## 📞 Getting Help

- Check README.md for full documentation
- Review DEPLOYMENT.md for deployment help
- Check error logs in browser console
- Verify database connection

## 🎉 Next Steps

1. **Customize Design** - Edit styles.css
2. **Add Features** - Extend api.php
3. **Deploy** - Follow DEPLOYMENT.md
4. **Monitor** - Set up error tracking
5. **Backup** - Configure automated backups

## 📊 System Requirements

- PHP 7.4+
- MySQL 5.7+
- 50MB disk space
- Modern web browser
- Internet connection

## 🚀 Performance Tips

1. Enable caching in config.php
2. Optimize images before upload
3. Use CDN for static files
4. Enable gzip compression
5. Regular database maintenance

---

**You're all set!** Start building your social network with Synq! 🎉

For more help, visit the full documentation in README.md
