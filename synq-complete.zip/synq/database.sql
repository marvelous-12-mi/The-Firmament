-- ============================================
-- SYNQ SOCIAL MEDIA - COMPLETE DATABASE SCHEMA
-- ============================================

-- Create database
CREATE DATABASE IF NOT EXISTS synq_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE synq_db;

-- ============================================
-- USERS TABLE
-- ============================================
CREATE TABLE users (
  id INT PRIMARY KEY AUTO_INCREMENT,
  username VARCHAR(50) UNIQUE NOT NULL,
  email VARCHAR(120) UNIQUE NOT NULL,
  password VARCHAR(255) NOT NULL,
  full_name VARCHAR(120),
  bio TEXT,
  avatar_url VARCHAR(255),
  cover_url VARCHAR(255),
  website VARCHAR(255),
  location VARCHAR(100),
  is_verified BOOLEAN DEFAULT FALSE,
  is_private BOOLEAN DEFAULT FALSE,
  followers_count INT DEFAULT 0,
  following_count INT DEFAULT 0,
  posts_count INT DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_username (username),
  INDEX idx_email (email),
  INDEX idx_created_at (created_at)
);

-- ============================================
-- POSTS TABLE
-- ============================================
CREATE TABLE posts (
  id INT PRIMARY KEY AUTO_INCREMENT,
  user_id INT NOT NULL,
  caption TEXT,
  image_url VARCHAR(255),
  likes_count INT DEFAULT 0,
  comments_count INT DEFAULT 0,
  shares_count INT DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_user_id (user_id),
  INDEX idx_created_at (created_at)
);

-- ============================================
-- COMMENTS TABLE
-- ============================================
CREATE TABLE comments (
  id INT PRIMARY KEY AUTO_INCREMENT,
  post_id INT NOT NULL,
  user_id INT NOT NULL,
  text TEXT NOT NULL,
  likes_count INT DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (post_id) REFERENCES posts(id) ON DELETE CASCADE,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_post_id (post_id),
  INDEX idx_user_id (user_id),
  INDEX idx_created_at (created_at)
);

-- ============================================
-- LIKES TABLE
-- ============================================
CREATE TABLE likes (
  id INT PRIMARY KEY AUTO_INCREMENT,
  user_id INT NOT NULL,
  post_id INT,
  comment_id INT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (post_id) REFERENCES posts(id) ON DELETE CASCADE,
  FOREIGN KEY (comment_id) REFERENCES comments(id) ON DELETE CASCADE,
  UNIQUE KEY unique_post_like (user_id, post_id),
  UNIQUE KEY unique_comment_like (user_id, comment_id),
  INDEX idx_user_id (user_id),
  INDEX idx_post_id (post_id)
);

-- ============================================
-- FOLLOWS TABLE
-- ============================================
CREATE TABLE follows (
  id INT PRIMARY KEY AUTO_INCREMENT,
  follower_id INT NOT NULL,
  following_id INT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (follower_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (following_id) REFERENCES users(id) ON DELETE CASCADE,
  UNIQUE KEY unique_follow (follower_id, following_id),
  CHECK (follower_id != following_id),
  INDEX idx_follower_id (follower_id),
  INDEX idx_following_id (following_id)
);

-- ============================================
-- NOTIFICATIONS TABLE
-- ============================================
CREATE TABLE notifications (
  id INT PRIMARY KEY AUTO_INCREMENT,
  user_id INT NOT NULL,
  from_user_id INT,
  post_id INT,
  comment_id INT,
  type VARCHAR(50) NOT NULL,
  message TEXT,
  is_read BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (from_user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (post_id) REFERENCES posts(id) ON DELETE CASCADE,
  FOREIGN KEY (comment_id) REFERENCES comments(id) ON DELETE CASCADE,
  INDEX idx_user_id (user_id),
  INDEX idx_is_read (is_read),
  INDEX idx_created_at (created_at)
);

-- ============================================
-- SAVED_POSTS TABLE
-- ============================================
CREATE TABLE saved_posts (
  id INT PRIMARY KEY AUTO_INCREMENT,
  user_id INT NOT NULL,
  post_id INT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (post_id) REFERENCES posts(id) ON DELETE CASCADE,
  UNIQUE KEY unique_save (user_id, post_id),
  INDEX idx_user_id (user_id)
);

-- ============================================
-- HASHTAGS TABLE
-- ============================================
CREATE TABLE hashtags (
  id INT PRIMARY KEY AUTO_INCREMENT,
  tag VARCHAR(100) UNIQUE NOT NULL,
  count INT DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_tag (tag)
);

-- ============================================
-- POST_HASHTAGS TABLE
-- ============================================
CREATE TABLE post_hashtags (
  id INT PRIMARY KEY AUTO_INCREMENT,
  post_id INT NOT NULL,
  hashtag_id INT NOT NULL,
  FOREIGN KEY (post_id) REFERENCES posts(id) ON DELETE CASCADE,
  FOREIGN KEY (hashtag_id) REFERENCES hashtags(id) ON DELETE CASCADE,
  UNIQUE KEY unique_post_hashtag (post_id, hashtag_id),
  INDEX idx_post_id (post_id),
  INDEX idx_hashtag_id (hashtag_id)
);

-- ============================================
-- MESSAGES TABLE
-- ============================================
CREATE TABLE messages (
  id INT PRIMARY KEY AUTO_INCREMENT,
  sender_id INT NOT NULL,
  recipient_id INT NOT NULL,
  text TEXT NOT NULL,
  is_read BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (sender_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (recipient_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_sender_id (sender_id),
  INDEX idx_recipient_id (recipient_id),
  INDEX idx_created_at (created_at)
);

-- ============================================
-- STORIES TABLE
-- ============================================
CREATE TABLE stories (
  id INT PRIMARY KEY AUTO_INCREMENT,
  user_id INT NOT NULL,
  image_url VARCHAR(255) NOT NULL,
  expires_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_user_id (user_id),
  INDEX idx_expires_at (expires_at)
);

-- ============================================
-- BLOCKS TABLE
-- ============================================
CREATE TABLE blocks (
  id INT PRIMARY KEY AUTO_INCREMENT,
  blocker_id INT NOT NULL,
  blocked_id INT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (blocker_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (blocked_id) REFERENCES users(id) ON DELETE CASCADE,
  UNIQUE KEY unique_block (blocker_id, blocked_id),
  CHECK (blocker_id != blocked_id),
  INDEX idx_blocker_id (blocker_id)
);

-- ============================================
-- REPORTS TABLE
-- ============================================
CREATE TABLE reports (
  id INT PRIMARY KEY AUTO_INCREMENT,
  reporter_id INT NOT NULL,
  post_id INT,
  user_id INT,
  reason VARCHAR(255) NOT NULL,
  description TEXT,
  status VARCHAR(50) DEFAULT 'pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (reporter_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (post_id) REFERENCES posts(id) ON DELETE SET NULL,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
  INDEX idx_status (status),
  INDEX idx_created_at (created_at)
);

-- ============================================
-- SESSIONS TABLE
-- ============================================
CREATE TABLE sessions (
  id INT PRIMARY KEY AUTO_INCREMENT,
  user_id INT NOT NULL,
  token VARCHAR(255) UNIQUE NOT NULL,
  ip_address VARCHAR(45),
  user_agent VARCHAR(255),
  expires_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_user_id (user_id),
  INDEX idx_token (token)
);

-- ============================================
-- SAMPLE DATA (OPTIONAL)
-- ============================================

-- Insert sample users
INSERT INTO users (username, email, password, full_name, bio, location) VALUES
('demo_user', 'demo@synq.app', '$2y$10$YourHashedPasswordHere', 'Demo User', 'Welcome to Synq!', 'Earth'),
('john_doe', 'john@synq.app', '$2y$10$YourHashedPasswordHere', 'John Doe', 'Photography enthusiast', 'New York'),
('jane_smith', 'jane@synq.app', '$2y$10$YourHashedPasswordHere', 'Jane Smith', 'Travel & lifestyle', 'Los Angeles');

-- ============================================
-- VIEWS FOR COMMON QUERIES
-- ============================================

CREATE VIEW user_feed AS
SELECT 
  p.id,
  p.user_id,
  p.caption,
  p.image_url,
  p.likes_count,
  p.comments_count,
  p.created_at,
  u.username,
  u.full_name,
  u.avatar_url
FROM posts p
JOIN users u ON p.user_id = u.id
ORDER BY p.created_at DESC;

CREATE VIEW trending_posts AS
SELECT 
  p.id,
  p.user_id,
  p.caption,
  p.image_url,
  p.likes_count,
  p.comments_count,
  p.created_at,
  u.username,
  u.full_name,
  u.avatar_url,
  (p.likes_count + p.comments_count * 2 + p.shares_count * 3) as engagement_score
FROM posts p
JOIN users u ON p.user_id = u.id
WHERE p.created_at > DATE_SUB(NOW(), INTERVAL 7 DAY)
ORDER BY engagement_score DESC;

-- ============================================
-- DATABASE SETUP COMPLETE
-- ============================================
