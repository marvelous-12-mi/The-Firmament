# Synq Deployment Guide

Complete guide for deploying Synq to production environments.

## 🚀 Quick Start Deployment

### Option 1: Shared Hosting (Bluehost, GoDaddy, etc.)

1. **Upload Files via FTP**
   ```
   - Connect to your hosting via FTP
   - Upload all files to public_html directory
   - Keep config.php outside public directory if possible
   ```

2. **Create Database**
   ```
   - Log into cPanel
   - Create new MySQL database
   - Create database user
   - Add user to database with all privileges
   ```

3. **Import Database Schema**
   ```
   - Go to phpMyAdmin
   - Select your database
   - Click "Import"
   - Choose database.sql file
   - Click "Go"
   ```

4. **Configure Application**
   ```
   - Edit config.php
   - Update DB_HOST, DB_USER, DB_PASS, DB_NAME
   - Update APP_URL to your domain
   - Update JWT_SECRET to a strong value
   ```

5. **Set Permissions**
   ```
   - Set uploads/ directory to 755
   - Set config.php to 644
   ```

### Option 2: DigitalOcean Droplet

1. **Create Droplet**
   ```bash
   # Select Ubuntu 20.04 LTS
   # Choose at least 1GB RAM
   # Add SSH key
   ```

2. **Initial Setup**
   ```bash
   ssh root@your_droplet_ip
   
   # Update system
   apt update && apt upgrade -y
   
   # Install dependencies
   apt install -y apache2 php php-mysql php-gd php-curl mysql-server
   
   # Enable Apache modules
   a2enmod rewrite
   systemctl restart apache2
   ```

3. **Setup MySQL**
   ```bash
   mysql_secure_installation
   
   # Create database
   mysql -u root -p
   CREATE DATABASE synq_db;
   CREATE USER 'synq_user'@'localhost' IDENTIFIED BY 'strong_password';
   GRANT ALL PRIVILEGES ON synq_db.* TO 'synq_user'@'localhost';
   FLUSH PRIVILEGES;
   EXIT;
   ```

4. **Deploy Application**
   ```bash
   cd /var/www/html
   git clone https://github.com/yourusername/synq.git
   cd synq
   
   # Set permissions
   chmod 755 uploads
   chmod 644 config.php
   ```

5. **Configure Apache**
   ```bash
   # Create virtual host
   nano /etc/apache2/sites-available/synq.conf
   ```
   
   Add:
   ```apache
   <VirtualHost *:80>
       ServerName your-domain.com
       ServerAlias www.your-domain.com
       DocumentRoot /var/www/html/synq
       
       <Directory /var/www/html/synq>
           AllowOverride All
           Require all granted
       </Directory>
       
       ErrorLog ${APACHE_LOG_DIR}/synq-error.log
       CustomLog ${APACHE_LOG_DIR}/synq-access.log combined
   </VirtualHost>
   ```
   
   ```bash
   a2ensite synq.conf
   systemctl restart apache2
   ```

6. **Setup SSL with Let's Encrypt**
   ```bash
   apt install -y certbot python3-certbot-apache
   certbot --apache -d your-domain.com -d www.your-domain.com
   ```

### Option 3: Heroku

1. **Install Heroku CLI**
   ```bash
   curl https://cli-assets.heroku.com/install.sh | sh
   heroku login
   ```

2. **Prepare Application**
   ```bash
   cd synq
   echo "web: vendor/bin/heroku-php-apache2" > Procfile
   echo "*.log" >> .gitignore
   ```

3. **Create Heroku App**
   ```bash
   heroku create your-app-name
   ```

4. **Add Database**
   ```bash
   heroku addons:create cleardb:ignite
   ```

5. **Deploy**
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git push heroku main
   ```

### Option 4: AWS EC2

1. **Launch EC2 Instance**
   - Choose Amazon Linux 2 or Ubuntu 20.04
   - t2.micro or larger
   - Configure security group (allow 80, 443, 22)

2. **Connect and Setup**
   ```bash
   ssh -i your-key.pem ec2-user@your-instance-ip
   
   # Install dependencies
   sudo yum update -y
   sudo yum install -y httpd php php-mysql mysql-server
   sudo systemctl start httpd
   sudo systemctl start mysqld
   ```

3. **Deploy Application**
   ```bash
   cd /var/www/html
   sudo git clone https://github.com/yourusername/synq.git
   sudo chown -R apache:apache synq
   ```

4. **Configure Database**
   ```bash
   sudo mysql_secure_installation
   # Create database and user as shown above
   ```

## 🔒 Production Security Checklist

- [ ] Change JWT_SECRET to a strong, random value
- [ ] Enable HTTPS/SSL certificate
- [ ] Update database credentials
- [ ] Set proper file permissions (644 for files, 755 for directories)
- [ ] Disable directory listing
- [ ] Enable Apache mod_rewrite
- [ ] Set up firewall rules
- [ ] Configure automated backups
- [ ] Set up monitoring and alerts
- [ ] Enable error logging
- [ ] Disable debug mode
- [ ] Update all dependencies
- [ ] Configure rate limiting
- [ ] Set up DDoS protection
- [ ] Enable CORS if needed

## 📊 Performance Optimization

1. **Enable Caching**
   ```php
   // Add to config.php
   header('Cache-Control: public, max-age=3600');
   ```

2. **Enable Gzip Compression**
   ```apache
   <IfModule mod_deflate.c>
       AddOutputFilterByType DEFLATE text/html text/plain text/xml text/css text/javascript application/javascript
   </IfModule>
   ```

3. **Optimize Images**
   - Compress images before upload
   - Use WebP format when possible
   - Implement lazy loading

4. **Database Optimization**
   - Ensure indexes are created
   - Regular database maintenance
   - Archive old data

5. **CDN Setup**
   - Use CloudFlare for static assets
   - Distribute content globally
   - Reduce server load

## 🔄 Backup Strategy

1. **Automated Database Backups**
   ```bash
   # Create backup script
   #!/bin/bash
   BACKUP_DIR="/backups/synq"
   DATE=$(date +%Y%m%d_%H%M%S)
   mysqldump -u synq_user -p synq_db > $BACKUP_DIR/synq_$DATE.sql
   gzip $BACKUP_DIR/synq_$DATE.sql
   ```

2. **File Backups**
   ```bash
   tar -czf /backups/synq_files_$(date +%Y%m%d).tar.gz /var/www/html/synq
   ```

3. **Schedule with Cron**
   ```bash
   # Run daily at 2 AM
   0 2 * * * /path/to/backup-script.sh
   ```

## 📈 Monitoring

1. **Server Monitoring**
   - CPU usage
   - Memory usage
   - Disk space
   - Network traffic

2. **Application Monitoring**
   - Error rates
   - Response times
   - Database queries
   - User activity

3. **Uptime Monitoring**
   - Use services like UptimeRobot
   - Monitor critical endpoints
   - Set up alerts

## 🚨 Troubleshooting

### 404 Errors
- Check .htaccess file
- Verify mod_rewrite is enabled
- Check file permissions

### Database Connection Errors
- Verify credentials in config.php
- Check database server is running
- Verify firewall rules

### Slow Performance
- Check database indexes
- Enable caching
- Optimize images
- Check server resources

### CORS Issues
- Update CORS headers in config.php
- Check allowed origins
- Verify preflight requests

## 📝 Maintenance

1. **Regular Updates**
   ```bash
   # Update system packages
   apt update && apt upgrade -y
   
   # Update PHP and MySQL
   apt install --only-upgrade php mysql-server
   ```

2. **Log Rotation**
   ```bash
   # Configure logrotate
   nano /etc/logrotate.d/synq
   ```

3. **Database Maintenance**
   ```bash
   # Optimize tables
   OPTIMIZE TABLE users, posts, comments, likes, follows;
   ```

## 🎯 Post-Deployment

1. **Test All Features**
   - User registration
   - Login/logout
   - Create posts
   - Like/comment
   - Follow users

2. **Monitor Logs**
   ```bash
   tail -f /var/log/apache2/error.log
   tail -f /var/log/apache2/access.log
   ```

3. **Set Up Monitoring**
   - Application performance
   - Error tracking
   - User analytics

4. **Configure Backups**
   - Automated daily backups
   - Off-site backup storage
   - Backup verification

## 📞 Support

For deployment issues:
- Check logs in `/var/log/`
- Review config.php settings
- Verify database connection
- Check file permissions
- Review Apache configuration

---

**Deployment completed successfully!** 🎉
